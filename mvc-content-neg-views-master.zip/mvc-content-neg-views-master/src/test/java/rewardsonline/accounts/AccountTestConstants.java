package rewardsonline.accounts;

public interface AccountTestConstants {
	public static final String TEST_ACCOUNT_NUMBER = "123456789";
	public static final String TEST_USER = "Sam Dunlap";
	public static final String TEST_USERNAME = "samd";
	public static final String TEST_USER_NUMBER= "1000";
	public static final String TEST_ACCOUNT_TYPE = Account.CREDIT;
}
